#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb  3 17:04:01 2024

@author: kaimulcock
"""

from iminuit import Minuit, cost
import numpy as np
from scipy.integrate import simpson
import matplotlib.pyplot as plt
from scipy.optimize import minimize

def forgetting(x, h):
    x = np.array(x)
    return 100*(2**(-x/h))

def h_curve(h_init, scaling, repetition_num):
    return h_init*(scaling**repetition_num)

def remember(study_times, h, x_end, scaling, steps=1000):
    memory = np.array([])
    t_prev = 0
    x = np.array([])
    # assert(x_end > study_times[-1])
    study_times[study_times > x_end] = x_end
    
    for i, t in enumerate(study_times):
        memory = np.append(memory, forgetting(np.linspace(0, t-t_prev, steps), h_curve(h, scaling, i)))
        x = np.append(x, np.linspace(t_prev, t, steps))
        t_prev = t
    
    x = np.append(x, np.linspace(t_prev, x_end, steps))
    memory = np.append(memory, forgetting(np.linspace(0, x_end - t_prev, steps), h_curve(h, scaling, len(study_times))))
    # x = np.append(x, x_end)
    # memory = np.append(memory, [100])
    return x, memory

def area_optimise(ts, h, x_end, scaling):
    x, y = remember(ts, h, x_end, scaling)
    return -np.sqrt(y[-1])*simpson(y, x)
