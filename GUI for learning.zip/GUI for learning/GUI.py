#%%
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 3 16:29:53 2024

@author: kaimulcock
"""

import tkinter as tk
import os
import numpy as np
from tkinter import messagebox
from datetime import datetime, timedelta
from Backend import *

# Global variables for quiz state
current_question_index = 0
questions = []
ExpectedAnswers = []
answers = []

# Initialize the main application window
SignInRoot = tk.Tk()
SignInRoot.title("Login Page")

def ReturnPassandUsername(username_entry, password_entry, window_to_close):
    global SavedAccounts
    file_path = "./Data/Accounts.txt"
    
    # Check if the file exists and has content
    if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
        SavedAccounts = np.loadtxt(file_path, dtype=str, ndmin=2)
    else:
        SavedAccounts = np.array([], dtype=str).reshape(0, 2)
    
    DesiredUsername = username_entry.get()
    DesiredPassword = password_entry.get()
    if DesiredUsername == "" or DesiredPassword == "":
        messagebox.showerror("Error", "Please input text")
        return
    
    # Check if the username already exists
    if SavedAccounts.size > 0 and any(SavedAccounts[:, 0] == DesiredUsername):
        messagebox.showerror("Error", "Username already in use")
    else:
        newEntry = np.array([DesiredUsername, DesiredPassword]).reshape(1, 2)
        if SavedAccounts.size == 0:
            SavedAccounts = newEntry
        else:
            SavedAccounts = np.vstack((SavedAccounts, newEntry))
        print("Updated SavedAccounts:", SavedAccounts)
        # Optionally, save back to file
        np.savetxt(file_path, SavedAccounts, fmt='%s', delimiter=" ")
    
    window_to_close.destroy()  # Close the current window
    SignInRoot.deiconify()  # Show the previous window

def RegisterPage():
    SignInRoot.withdraw()
    
    Register_Window = tk.Toplevel(SignInRoot)
    Register_Window.title("Register your Profile")
    label2 = tk.Label(Register_Window, text="Username")
    label2.grid(row=1, column=0, padx=10, pady=10, sticky="w")

    username_entry = tk.Entry(Register_Window)
    username_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")

    label3 = tk.Label(Register_Window, text="Password:")
    label3.grid(row=2, column=0, padx=10, pady=10, sticky="w")

    password_entry = tk.Entry(Register_Window, show="*")
    password_entry.grid(row=2, column=1, padx=10, pady=10)
    
    NewRegister_button = tk.Button(Register_Window, text="Register!", command=lambda: ReturnPassandUsername(username_entry, password_entry, Register_Window))
    NewRegister_button.grid(row=3, column=1, padx=50, pady=10)
    
    back_button = tk.Button(Register_Window, text="Back to Sign In", command=lambda: ReturnToSignIn(Register_Window))
    back_button.grid(row=3, column=0, padx=50, pady=10)

def ReturnToSignIn(window_to_close):
    window_to_close.destroy()  # Close the current window
    SignInRoot.deiconify()  # Show the previous window

def SigninProcess(username_entry, password_entry):
    global SavedAccounts
    file_path = "./Data/Accounts.txt"
    
    # Check if the file exists and has content
    if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
        SavedAccounts = np.loadtxt(file_path, dtype=str, ndmin=2)
    else:
        messagebox.showerror("Error", "Please Register First")
        return  # Exit the function if the file doesn't exist
    global Username
    Username = username_entry.get()
    Password = password_entry.get()
    if Username == "" or Password == "":
        messagebox.showerror("Error", "Please input text")
        return  # Exit the function if input is invalid
    
    # Check if the username and password match
    if any((SavedAccounts[:, 0] == Username) & (SavedAccounts[:, 1] == Password)):
        # messagebox.showinfo("Login Successful", "Welcome back!")
        SignInRoot.withdraw()  # Hide the sign-in window
        QuizPage()  # Proceed to the quiz page
    else:
        messagebox.showerror("Error", "Invalid login details")

def QuizPage():
    global quiz_page_window
    quiz_page_window = tk.Toplevel(SignInRoot)
    quiz_page_window.title("Personal Homepage")
    
    quiz_button = tk.Button(quiz_page_window, text="Take your Quiz", command=lambda: TakeQuiz(quiz_page_window))
    quiz_button.grid(row=0, column=0, padx=50, pady=10)

    stats_button = tk.Button(quiz_page_window, text="See your Stats", command=lambda: SeeStats(quiz_page_window))
    stats_button.grid(row=0, column=1, padx=50, pady=10)

def TakeQuiz(quiz_page_window):
    quiz_page_window.withdraw()
    global current_question_index, question_label, question_answer_entry, answers, questions, ExpectedAnswers, AnswerLabel, quiz_window
    quiz_window = tk.Toplevel(SignInRoot)
    quiz_window.title("Take Test Quiz")
    
    current_question_index = 0
    answers = []

    # Load questions and answers
    file_path = "Country-capitals_test.txt"
    if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
        Input = np.loadtxt(file_path, dtype=str, delimiter=",")
        questions = Input[::2]  # Even indices are questions
        ExpectedAnswers = Input[1::2]  # Odd indices are answers

    question_label = tk.Label(quiz_window, text=questions[current_question_index])
    question_label.grid(row=0, column=0, padx=50, pady=10)

    question_answer_entry = tk.Entry(quiz_window)
    question_answer_entry.grid(row=1, column=0, padx=50, pady=10)
    
    AnswerLabel = tk.Label(quiz_window, text="")
    AnswerLabel.grid(row=2, column=0, padx=50, pady=10)
    AnswerLabel.grid_remove()  # Hide the answer label initially

    ProceedButton = tk.Button(quiz_window, text="Complete Answer", command=lambda: show_answer_and_proceed(question_answer_entry))
    ProceedButton.grid(row=3, column=0, padx=50, pady=10)

def show_answer_and_proceed(Entry):
    global current_question_index, answers, quiz_window

    answers.append(Entry.get())
    question_answer_entry.delete(0, tk.END)

    AnswerLabel.config(text=ExpectedAnswers[current_question_index])
    AnswerLabel.grid()  # Show the answer

    quiz_window.after(2000, proceed_to_next_question)  # Wait 3 seconds before proceeding

def proceed_to_next_question():
    global current_question_index, questions, ExpectedAnswers, AnswerLabel

    current_question_index += 1
    if current_question_index < len(questions):
        question_label.config(text=questions[current_question_index])
        AnswerLabel.config(text=ExpectedAnswers[current_question_index])
        AnswerLabel.grid_remove()  # Prepare for the next question
    else:
        # All questions have been answered, calculate the score
        calculate_and_display_score()

def calculate_and_display_score():
    global answers, ExpectedAnswers, quiz_window
    Score = 0  # Initialize score

    # def is_float(value):
    #     try:
    #         float(value)
    #         return True
    #     except ValueError:
    #         return False
    
    # # Calculate score
    # for i in range(len(answers)):
    #     if answers[i].strip().lower() == ExpectedAnswers[i].strip().lower():
    #         Score += 1
    #         global Percentage
    #         Percentage = 100*Score/len(ExpectedAnswers)
    #         studentData = np.loadtxt("./Data/Student info.txt",delimiter=",",dtype=object)
    #         # studentData[:, 1:] = studentData[:, 1:].astype(float)
    #         idx = np.where(studentData[:, 0] == Username)[0]
    #         if len(idx) == 0:
    #             SpecificstudentData = [Username, 1, 2, 1.5]
    #             CalculateNextTime(SpecificstudentData)
    #             SpecificstudentData = np.array([Username, 2, hval, scaling], dtype=object)
    #             studentData = np.vstack((studentData, SpecificstudentData), dtype=object)
    #         else:
    #             SpecificstudentData = studentData[idx]
    #             CalculateNextTime(SpecificstudentData)
    #             studentData[idx] = np.array([Username, 2, hval, scaling], dtype=object)
    #         for col in range(1, studentData.shape[1]):
    #             studentData[:, col] = [float(val) if is_float(val) else val for val in studentData[:, col]]
    #         np.savetxt("./Data/Student info.txt", studentData, fmt='%s', delimiter=",")
            
    Score = 0  # Initialize score

    # Calculate score
    for i in range(len(answers)):
        if answers[i].strip().lower() == ExpectedAnswers[i].strip().lower():
            Score += 1
            global Percentage
            Percentage = 100*Score/len(ExpectedAnswers)
            studentData = np.loadtxt("Data/Student info.txt",delimiter=",",dtype=object)
            SpecificstudentData = studentData[np.where(studentData[:, 0] == Username)[0]][0]
            print(SpecificstudentData)
            CalculateNextTime(SpecificstudentData)
    
    
    # Optionally, close the quiz window or reset the quiz for another round
    quiz_window.destroy()  # Close the quiz window
    quiz_page_window.deiconify()  # Show the main window again

def SeeStats(quiz_page_window):
    quiz_page_window.withdraw()
    stats_window = tk.Toplevel(SignInRoot)
    stats_window.title("Your Stats")
    # Implement stats display
    
    try:
        Percentage_label = tk.Label(stats_window, text="Your Previous Attempt's Score:")
        Percentage_label.grid(row=0, column=0, padx=50, pady=10)
        # Percentage = format(Percentage, '.2f')
        PercentageValue_label = tk.Label(stats_window, text=round(Percentage,2))
        PercentageValue_label.grid(row=0, column=1, padx=50, pady=10)
        
        NextSession_label = tk.Label(stats_window, text="Your Next Session Is Due On:")
        NextSession_label.grid(row=1, column=0, padx=50, pady=10)
        
        NextSessionValue_label = tk.Label(stats_window, text=DateofRepeat)
        NextSessionValue_label.grid(row=1, column=1, padx=50, pady=10)
        
        HLabel_label = tk.Label(stats_window, text="Your Current H Index Is:")
        HLabel_label.grid(row=2, column=0, padx=50, pady=10)
        
        HValueLabel_label = tk.Label(stats_window, text=hval)
        HValueLabel_label.grid(row=2, column=1, padx=50, pady=10)
    except:
        Percentage_label = tk.Label(stats_window, text="       No Previous Attempts       ")
        Percentage_label.grid(row=0, column=0, padx=50, pady=10)
    
    
def CalculateNextTime(StudentInfoFile):
    #Student info file => (Username, timestep, h)
    global DateofRepeat, hval, scaling

    DateofRepeat, hval, scaling = StudentInfoFile[1:]
    
    # Get the current date
    current_date = datetime.now()
    
    confidence = 0.8
    x_end = 50
    scaling = 1.5
    tot_area = x_end*100*np.sqrt(100)
    

    strength = 0
    n = 1
    while strength < confidence*tot_area:
        p0 = np.sort(np.random.uniform(0, x_end, n))
        res = minimize(area_optimise, p0, args=(hval, x_end, scaling), bounds=len(p0)*[(0, x_end)])
        strength = -res.fun
        n += 1

    repetitions = res.x
    predicted_days = repetitions[0]

    totmins = int(24*60*(predicted_days - int(predicted_days)))
    hoursto = totmins//60
    minsto = totmins - hoursto*60
    predicted_repetition_date = current_date + timedelta(days=np.floor(predicted_days), hours=hoursto, minutes=minsto)
    
    # Format the future date in day/month/year format
    DateofRepeat = predicted_repetition_date.date()
    
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    hval *= scaling   # Calculate this (from maximising algorithm)!!!!!
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
    ##############################3Should be ok just editing this function, 
    #maybe ofc aroudn this too like editing inputs
    # Return the time till next revision period and the h value maybe?
    
    # give DateofRepeat = and hval =  (also can call )as these are global vairables used in see Stats
    

# def confirm_close(window):
#     raise SystemExit()

# GUI Elements for SignInRoot
label1 = tk.Label(SignInRoot, text="Enter your Account Details:")
label1.grid(row=0, column=0, columnspan=2, padx=10, pady=10)


label2 = tk.Label(SignInRoot, text="Username")
label2.grid(row=1, column=0, padx=10, pady=10, sticky="w")

username_entry = tk.Entry(SignInRoot)
username_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")

label3 = tk.Label(SignInRoot, text="Password:")
label3.grid(row=2, column=0, padx=10, pady=10, sticky="w")

password_entry = tk.Entry(SignInRoot, show="*")
password_entry.grid(row=2, column=1, padx=10, pady=10)

login_button = tk.Button(SignInRoot, text="Sign in!", command=lambda: SigninProcess(username_entry, password_entry))
login_button.grid(row=3, column=0, padx=50, pady=10)

register_button = tk.Button(SignInRoot, text="Register!", command=RegisterPage)
register_button.grid(row=3, column=1, padx=50, pady=10)

SignInRoot.mainloop()

#%%